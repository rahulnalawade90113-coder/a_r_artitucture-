let slideIndex = 0;
const slides = document.querySelectorAll(".slide");
const dotsContainer = document.querySelector(".dots-container");

// Create dots dynamically
slides.forEach((_, i) => {
    const dot = document.createElement("span");
    dot.classList.add("dot");
    dot.setAttribute("onclick", `setSlide(${i})`);
    dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll(".dot");

function showSlide(index) {
    slideIndex = index;
    const offset = -slideIndex * 100;
    document.querySelector(".carousel").style.transform = `translateX(${offset}%)`;
    
    dots.forEach(dot => dot.classList.remove("active"));
    dots[slideIndex].classList.add("active");
}

function nextSlide() {
    slideIndex = (slideIndex + 1) % slides.length;
    showSlide(slideIndex);
}

function prevSlide() {
    slideIndex = (slideIndex - 1 + slides.length) % slides.length;
    showSlide(slideIndex);
}

function setSlide(index) {
    showSlide(index);
}

// Auto slide every 3 seconds
setInterval(nextSlide, 3000);

// Initialize first slide
showSlide(slideIndex);


document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    const quoteBtn = document.querySelector('.quote-btn');
    
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            // Toggle quote button visibility on mobile
            if (window.innerWidth <= 767) {
                quoteBtn.classList.toggle('mobile-visible');
            }
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.navbar')) {
                navLinks.classList.remove('active');
                quoteBtn.classList.remove('mobile-visible');
            }
        });
    }
    
    // Handle dropdown menus on mobile
    const dropdownToggles = document.querySelectorAll('.nav-links > li');
    dropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            if (window.innerWidth <= 767 && this.querySelector('.dropdown-menu')) {
                e.preventDefault();
                this.classList.toggle('active');
            }
        });
    });
    
    // Window resize handler
    window.addEventListener('resize', function() {
        if (window.innerWidth > 767) {
            navLinks.classList.remove('active');
            quoteBtn.classList.remove('mobile-visible');
            // Reset dropdowns
            document.querySelectorAll('.nav-links > li').forEach(item => {
                item.classList.remove('active');
            });
        }
    });
});




