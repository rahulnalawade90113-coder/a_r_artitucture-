package in.programing.architecture_website.team;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class TeamController {

    @Autowired
    private TeamService teamService;
    
    private static final String UPLOAD_DIR = "src/main/resources/static/teams/";

    @GetMapping("/teams/{filename}")
    @ResponseBody
    public ResponseEntity<Resource> getImage(@PathVariable String filename) {
        try {
            Path imagePath = Paths.get(UPLOAD_DIR).resolve(filename);
            Resource resource = new UrlResource(imagePath.toUri());

            if (resource.exists()) {
                return ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_JPEG)
                        .body(resource);
            } else {
                throw new RuntimeException("Image not found");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error loading image: " + filename, e);
        }
    }

    @GetMapping("/teams-list")
    public String getAllTeams(Model model) {
        List<Team> teams = teamService.getAllTeams();
        model.addAttribute("teams", teams);
        return "admin-teamlist";
    }
    

	
    @GetMapping("/teams-add")
    public String showAddForm() {
        return "admin-addteam";
    }

    @PostMapping("/teams-add")
    public String addTeam(
            @RequestParam("name") String name, 
            @RequestParam("profile") String profile, 
            @RequestParam("email") String email,
            @RequestParam("description") String description,
            @RequestParam("imageFile") MultipartFile imageFile) {
        try {
            teamService.addTeam(name, profile, email, description, imageFile); 
            return "redirect:/teams-list";
        } catch (IOException e) {
            return "Error uploading image: " + e.getMessage();
        }
    }

    @PostMapping("/teams-edit-{id}")
    public String editTeam(
        @PathVariable Long id, 
        @RequestParam("name") String name, 
        @RequestParam("profile") String profile, 
        @RequestParam("email") String email,
        @RequestParam("description") String description,
        @RequestParam(value = "imageFile", required = false) MultipartFile imageFile) {
        
        try {
            teamService.updateTeam(id, name, profile, email, description, imageFile); 
            return "redirect:/teams-list";
        } catch (IOException e) {
            e.printStackTrace();
            return "error-page";
        }
    }

    @GetMapping("/teams-edit-{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Optional<Team> team = teamService.getTeamById(id);
        if (team.isPresent()) {
            model.addAttribute("team", team.get());
            return "admin-team-edit";
        } else {
            return "team-not-found";
        }
    }

   

    @GetMapping("/teams-delete-{id}")
    public String deleteTeam(@PathVariable Long id) {
        teamService.deleteTeam(id);
        return "redirect:/teams-list";
    }
}
