package in.programing.architecture_website.admin;

import lombok.Data;

@Data
public class Admin {
	    private String adminname;
	    private String password;

	    
	}
