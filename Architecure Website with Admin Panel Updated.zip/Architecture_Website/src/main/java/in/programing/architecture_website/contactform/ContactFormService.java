package in.programing.architecture_website.contactform;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@Service
@Transactional
public class ContactFormService {

    private final ContactFormRepository contactFormRepository;

    public ContactFormService(ContactFormRepository contactFormRepository) {
        this.contactFormRepository = contactFormRepository;
    }

    public Page<ContactForm> getAllContactForms(Pageable pageable) {
        return contactFormRepository.findAll(pageable);
    }

    public ContactForm getContactFormById(Long id) {
        return contactFormRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Contact form not found with id: " + id));
    }

    public ContactForm saveContactForm(ContactForm contactForm) {
        return contactFormRepository.save(contactForm);
    }

    public void deleteContactForm(Long id) {
        contactFormRepository.deleteById(id);
    }
}