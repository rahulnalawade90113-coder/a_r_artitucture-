package in.programing.architecture_website.about;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AboutService {
    @Autowired
    private AboutRepository aboutRepository;

    public About saveAbout(String name, String title, String shortName, 
                         String description, String logoEmoji) {
        About about = new About(name, title, shortName, description, logoEmoji);
        return aboutRepository.save(about);
    }

    public About updateAbout(Long id, String name, String title, String shortName, 
                           String description, String logoEmoji) {
        About existing = getAboutById(id);
        if (existing == null) {
            return null;
        }

        existing.setName(name);
        existing.setTitle(title);
        existing.setShortName(shortName);
        existing.setDescription(description);
        existing.setLogoEmoji(logoEmoji);

        return aboutRepository.save(existing);
    }

    public List<About> getAllAbout() {
        return aboutRepository.findAllByOrderByIdDesc();
    }

    public About getAboutById(Long id) {
        return aboutRepository.findById(id).orElse(null);
    }

    public void deleteAbout(Long id) {
        aboutRepository.deleteById(id);
    }

    public Optional<About> getAboutByName(String name) {
        return aboutRepository.findByName(name);
    }
    
    // Additional useful methods you might want to add:
    public boolean existsByName(String name) {
        return aboutRepository.existsByName(name);
    }
    
    public List<About> searchAboutByKeyword(String keyword) {
        return aboutRepository.findByNameContainingIgnoreCaseOrTitleContainingIgnoreCase(
            keyword, keyword);
    }
    public List<About> findByNameContainingIgnoreCase(String name) {
        return aboutRepository.findByNameContainingIgnoreCase(name);
    }
}
