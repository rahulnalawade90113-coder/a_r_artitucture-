package in.programing.architecture_website;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchitectureWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchitectureWebsiteApplication.class, args);
	}

}