package in.programing.architecture_website.admin;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;


    
   
    @GetMapping("/login")
    public String login() {
        return "admin-login";
    }

  
    @PostMapping("/login")
    public String handleLogin(@RequestParam String username, 
                              @RequestParam String password, 
                              Model model) {
        if (authenticate(username, password)) {
            model.addAttribute("message", "Login successful!");
            return "admin-dashboard"; 
        } else {
            model.addAttribute("error", "Invalid username or password!");
            return "admin-dashboard"; 
        }
    }

    private boolean authenticate(String username, String password) {
        return "admin".equals(username) && "12345".equals(password);
    }

  
    @GetMapping("/admin/logout")
    public String showLogoutPage(HttpSession session) {
        session.invalidate(); 
        return "redirect:/login"; 
    }

    
    @Secured("ROLE_ADMIN")
    @GetMapping("/admin-dashboard")
    public String home() {
        return "admin-dashboard";
    }

  
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping("/admin/settings")
    public String settings() {
        return "admin-settings";
    }

   
    @Secured("ROLE_ADMIN")
    @GetMapping("/admin/logs")
    public String logs() {
        return "admin-logs";
    }

   
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping("/admin/profile")
    public String profile() {
        return "admin-profile";
    }
}