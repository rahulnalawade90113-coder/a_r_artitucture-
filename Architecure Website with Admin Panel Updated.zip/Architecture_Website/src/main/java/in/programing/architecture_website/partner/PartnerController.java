package in.programing.architecture_website.partner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
public class PartnerController {

    public static final String UPLOAD_DIR = "static/partners/";

    @Autowired
    private PartnerService partnerService;

    @GetMapping("static/partners/{filename}")
    @ResponseBody
    public Resource getImage(@PathVariable String filename) {
        try {
            Path imagePath = Paths.get(UPLOAD_DIR).resolve(filename);
            Resource resource = new UrlResource(imagePath.toUri());

            if (resource.exists()) {
                return resource;
            } else {
                throw new RuntimeException("Image not found");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error loading image: " + filename, e);
        }
    }

    @GetMapping("/addpartner")
    public String showAddPartnerForm(Model model) {
        model.addAttribute("partner", new Partner());
        return "addpartner";
    }

    @PostMapping("/addpartner")
    public String savePartner(@RequestParam("name") String name,
                            @RequestParam("file") MultipartFile file,
                            RedirectAttributes redirectAttributes) {
        partnerService.savePartner(name, file);
        redirectAttributes.addFlashAttribute("success", "Partner added successfully!");
        return "redirect:/partnerlist";
    }

    @GetMapping("/partnerlist")
    public String showPartnerList(Model model) {
        model.addAttribute("partners", partnerService.getAllPartners());
        return "partnerlist";
    }

    @GetMapping("/partners")
    public String showPartnersPage(Model model) {
        model.addAttribute("partners", partnerService.getAllPartners());
        return "partners";
    }

    @GetMapping("/partner/delete/{id}")
    public String deletePartner(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Partner partner = partnerService.getPartnerById(id);
        if (partner != null) {
            partnerService.deletePartnerById(id);
            redirectAttributes.addFlashAttribute("success", "Partner deleted successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Partner not found!");
        }
        return "redirect:/partnerlist";
    }
}
