package in.programing.architecture_website.achievement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
public class AchievementController {
    public static final String UPLOAD_DIR = "static/achievements/";

    @Autowired
    private AchievementService achievementService;

    @GetMapping("static/achievements/{filename}")
    @ResponseBody
    public Resource getImage(@PathVariable String filename) {
        try {
            Path imagePath = Paths.get(UPLOAD_DIR).resolve(filename);
            Resource resource = new UrlResource(imagePath.toUri());

            if (resource.exists()) {
                return resource;
            } else {
                throw new RuntimeException("Image not found");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error loading image: " + filename, e);
        }
    }

    @GetMapping("/addachievement")
    public String showAddAchievementForm(Model model) {
        model.addAttribute("achievement", new Achievement());
        return "admin-addachievement";
    }

    @PostMapping("/addachievement")
    public String saveAchievement(@RequestParam("title") String title,
                                @RequestParam("shortDescription") String shortDescription,
                                @RequestParam("fullDescription") String fullDescription,
                                @RequestParam("file") MultipartFile file,
                                RedirectAttributes redirectAttributes) {
        achievementService.saveAchievement(title, shortDescription, fullDescription, file);
        redirectAttributes.addFlashAttribute("success", "Achievement added successfully!");
        return "redirect:/achievementlist";
    }

    @GetMapping("/achievementlist")
    public String showAchievementList(Model model) {
        model.addAttribute("achievements", achievementService.getAllAchievements());
        return "admin-achievementlist";
    }

    @GetMapping("/achievements")
    public String showAchievementsPage(Model model) {
        model.addAttribute("achievements", achievementService.getAllAchievements());
        return "achievements";
    }

    @GetMapping("/achievement/delete/{id}")
    public String deleteAchievement(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        achievementService.deleteAchievement(id);
        redirectAttributes.addFlashAttribute("success", "Achievement deleted successfully!");
        return "redirect:/achievementlist";
    }

    @GetMapping("/achievement-edit-{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Achievement achievement = achievementService.getAchievementById(id);
        model.addAttribute("achievement", achievement);
        return "admin-editachievement";
    }

    @PostMapping("/achievement-update-{id}")
    public String updateAchievement(@PathVariable Long id,
                                  @RequestParam("title") String title,
                                  @RequestParam("shortDescription") String shortDescription,
                                  @RequestParam("fullDescription") String fullDescription,
                                  @RequestParam(value = "file", required = false) MultipartFile file,
                                  RedirectAttributes redirectAttributes) {
        Achievement existing = achievementService.getAchievementById(id);
        
        if (file != null && !file.isEmpty()) {
            String newImage = achievementService.saveImage(file);
            if (newImage != null) {
                achievementService.deleteImage(existing.getImageFilename());
                existing.setImageFilename(newImage);
            }
        }
        
        existing.setTitle(title);
        existing.setShortDescription(shortDescription);
        existing.setFullDescription(fullDescription);
        
        achievementService.saveAchievement(existing);
        redirectAttributes.addFlashAttribute("success", "Achievement updated successfully!");
        return "redirect:/achievementlist";
    }
}