package in.programing.architecture_website.admin;

import org.springframework.stereotype.Service;

@Service
public class AdminService {
	
	    public boolean authenticate(Admin admin) {
	       
	        return "admin".equals(admin.getAdminname()) && "password".equals(admin.getPassword());        
	    }  
	}