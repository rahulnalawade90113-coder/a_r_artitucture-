package in.programing.architecture_website.team;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Optional;

@Service
public class TeamService {

    private static final String UPLOAD_DIR = "src/main/resources/static/teams/";
    private final TeamRepository teamRepository;

    public TeamService(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    
    public void addTeam(String name, String profile, String email, String description, MultipartFile imageFile) throws IOException {
        String fileName = saveImage(imageFile);
        Team team = new Team(name, profile, fileName, email, description);
        teamRepository.save(team);
    }

   
    public void updateTeam(Long id, String name, String profile, String email, String description, MultipartFile imageFile) throws IOException {
        Optional<Team> optionalTeam = teamRepository.findById(id);
        if (optionalTeam.isPresent()) {
            Team team = optionalTeam.get();
            team.setName(name);
            team.setProfile(profile);
            team.setEmail(email);
            team.setDescription(description);
            if (imageFile != null && !imageFile.isEmpty()) {
               
                deleteImageFile(team.getImageFilename());
             
                String fileName = saveImage(imageFile);
                team.setImageFilename(fileName);
            }
            teamRepository.save(team);
        } else {
            throw new RuntimeException("Team not found with id: " + id);
        }
    }

   
    public void deleteTeam(Long id) {
        Optional<Team> optionalTeam = teamRepository.findById(id);
        if (optionalTeam.isPresent()) {
            Team team = optionalTeam.get();
         
            deleteImageFile(team.getImageFilename());
            teamRepository.deleteById(id);
        } else {
            throw new RuntimeException("Team not found with id: " + id);
        }
    }

   
    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

   
    public Optional<Team> getTeamById(Long id) {
        return teamRepository.findById(id);
    }

  
    public Optional<Team> getTeamByName(String name) {
        return teamRepository.findByName(name);
    }

    
    private String saveImage(MultipartFile imageFile) throws IOException {
        if (imageFile != null && !imageFile.isEmpty()) {
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            String fileName = System.currentTimeMillis() + "_" + imageFile.getOriginalFilename();
            Path filePath = Paths.get(UPLOAD_DIR, fileName);
            Files.copy(imageFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            return fileName;
        }
        return null;
    }

   
    private void deleteImageFile(String fileName) {
        if (fileName != null && !fileName.isEmpty()) {
            File file = new File(UPLOAD_DIR + fileName);
            if (file.exists()) {
                file.delete();
            }
        }
    }
}
