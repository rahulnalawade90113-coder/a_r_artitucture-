package in.programing.architecture_website.achievement;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Achievement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String title;
    private String shortDescription;
    private String fullDescription;
    private String imageFilename;
    
    public Achievement() {}
    
    public Achievement(String title, String shortDescription, String fullDescription, String imageFilename) {
        this.title = title;
        this.shortDescription = shortDescription;
        this.fullDescription = fullDescription;
        this.imageFilename = imageFilename;
    }
}