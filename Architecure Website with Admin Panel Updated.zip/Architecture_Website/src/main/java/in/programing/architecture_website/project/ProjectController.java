package in.programing.architecture_website.project;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ProjectController {
    public static final String UPLOAD_DIR = "static/projects/";

    @Autowired
    private ProjectService projectService;

    @GetMapping("static/projects/{filename}")
    @ResponseBody
    public Resource getImage(@PathVariable String filename) {
        try {
            Path imagePath = Paths.get(UPLOAD_DIR).resolve(filename);
            Resource resource = new UrlResource(imagePath.toUri());

            if (resource.exists()) {
                return resource;
            } else {
                throw new RuntimeException("Image not found");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error loading image: " + filename, e);
        }
    }

    @GetMapping("/addproject")
    public String showAddProjectForm(Model model) {
        model.addAttribute("project", new Project());
        return "admin-addproject";
    }

    @PostMapping("/addproject")
    public String saveProject(@RequestParam("title") String title,
                            @RequestParam("name") String name,
                            @RequestParam("file") MultipartFile file,
                            @RequestParam("location") String location,
                            @RequestParam("area") String area,
                            RedirectAttributes redirectAttributes) {
        projectService.saveProject(title, name, file, location, area);
        redirectAttributes.addFlashAttribute("success", "Project added successfully!");
        return "redirect:/projectlist";
    }

    @GetMapping("/projectlist")
    public String showProjectList(Model model) {
        model.addAttribute("projects", projectService.getAllProjects());
        return "admin-projectlist";
    }

   

    @GetMapping("/project/delete/{id}")
    public String deleteProject(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        projectService.deleteProject(id);
        redirectAttributes.addFlashAttribute("success", "Project deleted successfully!");
        return "redirect:/projectlist";
    }
}
