package in.programing.architecture_website.team;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String profile;
    private String imageFilename;
    private String email; 
    private String description; 

    public Team(String name, String profile, String imageFilename, String email, String description) {
        this.name = name;
        this.profile = profile;
        this.imageFilename = imageFilename;
        this.email = email;
        this.description = description; 
    }
}