package in.programing.architecture_website.companydetails;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyDetailsRepository extends JpaRepository<CompanyDetails, Long> {
    List<CompanyDetails> findAllByOrderByIdDesc();
}
