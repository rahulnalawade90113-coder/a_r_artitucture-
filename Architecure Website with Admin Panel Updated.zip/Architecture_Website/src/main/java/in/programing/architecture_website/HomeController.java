package in.programing.architecture_website;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import in.programing.architecture_website.about.About;
import in.programing.architecture_website.about.AboutService;
import in.programing.architecture_website.achievement.AchievementService;
import in.programing.architecture_website.companydetails.CompanyDetailsService;
import in.programing.architecture_website.contact.ContactService;
import in.programing.architecture_website.contactform.ContactForm;
import in.programing.architecture_website.contactform.ContactFormService;
import in.programing.architecture_website.partner.PartnerService;
import in.programing.architecture_website.project.ProjectService;
import in.programing.architecture_website.team.Team;
import in.programing.architecture_website.team.TeamService;

@Controller
public class HomeController {

	@Autowired
    private TeamService teamService;
	
	 @Autowired
	 private ProjectService projectService;
	 
	 @Autowired
	  private PartnerService partnerService;
	 
	  @Autowired
	    private ContactService contactService;
	 
	@Autowired
    private ContactFormService contactFormService;
	
	  @Autowired
	  private CompanyDetailsService companyDetailsService;

   
	private static final String UPLOAD_DIR = "static/contact-forms/";

  
	@Autowired
    private AchievementService achievementService;
	
	 @Autowired
	    private AboutService aboutService;
	
	 @GetMapping("/home")
	    public String showHomePage(Model model) {	
		 model.addAttribute("projects", projectService.getAllProjects());
		 model.addAttribute("partners", partnerService.getAllPartners());
		  model.addAttribute("contacts", contactService.getAllContacts());
	        return "home";
	    }
	 
	 @GetMapping("/projects")
	    public String showProjectsPage(Model model) {
	        model.addAttribute("projects", projectService.getAllProjects());
	        model.addAttribute("contacts", contactService.getAllContacts());
	        return "projects";
	    }
	 
	 
	 @GetMapping("/about")
	    public String showAboutPage(Model model) {
	        model.addAttribute("companyDetailsList", companyDetailsService.getAllCompanyDetails());
	        List<About> aboutList = aboutService.getAllAbout();
	        model.addAttribute("aboutList", aboutList);
	        
	        // Set first tab as active if available
	        if (!aboutList.isEmpty()) {
	            model.addAttribute("activeTab", aboutList.get(0).getName().toLowerCase());
	            model.addAttribute("activeAbout", aboutList.get(0));
	            model.addAttribute("contacts", contactService.getAllContacts());
	        }
	        return "about";
	    }

	    @GetMapping("/about{name}")
	    public String showAboutByName(@PathVariable String name, Model model) {
	        model.addAttribute("companyDetailsList", companyDetailsService.getAllCompanyDetails());
	        List<About> aboutList = aboutService.getAllAbout();
	        model.addAttribute("aboutList", aboutList);
	        model.addAttribute("contacts", contactService.getAllContacts());
	        
	        // Find and set the active tab
	        Optional<About> activeAbout = aboutList.stream()
	            .filter(about -> about.getName().equalsIgnoreCase(name))
	            .findFirst();
	        
	        if (activeAbout.isPresent()) {
	            model.addAttribute("activeTab", name.toLowerCase());
	            model.addAttribute("activeAbout", activeAbout.get());
	        } else {
	            // Fallback to first tab if not found
	            model.addAttribute("activeTab", aboutList.get(0).getName().toLowerCase());
	            model.addAttribute("activeAbout", aboutList.get(0));
	        }
	        
	        return "about";
	    }
	    
	    

	 
	 @GetMapping("/contacts")
	    public String showContact() {		
	        return "contacts";
	    }
	 
	 @GetMapping("/architecturalservices")
	    public String showArchitecturalServices(Model model) {	
		 model.addAttribute("projects", projectService.getAllProjects());
		  model.addAttribute("contacts", contactService.getAllContacts());
	        return "architectural_services";
	    }
	 
	 @GetMapping("/InteriorDesignServices")
	    public String showInteriorDesignServices(Model model) {	
		 model.addAttribute("projects", projectService.getAllProjects());
		  model.addAttribute("contacts", contactService.getAllContacts());
	        return "InteriorDesignServices";
	    }
	 
	 @GetMapping("/ourachievements")
	 public String showAchievementsPage(Model model) {
	        model.addAttribute("achievements", achievementService.getAllAchievements());
	        model.addAttribute("contacts", contactService.getAllContacts());
	        return "ourachievements";
	    }
	 @GetMapping("/ourteam")
	    public String showOurTeam(Model model) {	
		 List<Team> teams = teamService.getAllTeams();
	        model.addAttribute("teams", teams);
	        model.addAttribute("contacts", contactService.getAllContacts());
	        return "ourteam";
	    }
	    @GetMapping("/contactform")
		 public String showContactForms(Model model) {
	    	  model.addAttribute("contactForm", new ContactForm());
	          model.addAttribute("captcha", generateSimpleCaptcha());
	          model.addAttribute("countries", Arrays.asList("USA", "UK", "India", "Canada", "Australia"));
	          model.addAttribute("contacts", contactService.getAllContacts());
		     return "contactform";
		 }

		 
		 @PostMapping("/contactform")
		  public String submitContactForms(@ModelAttribute("contactForm") ContactForm contactForm,
	              @RequestParam("files") MultipartFile[] files,
	              RedirectAttributes redirectAttributes) {

	// Validate CAPTCHA
	if (!contactForm.getCaptcha().equals(contactForm.getCaptchaInput())) {
	redirectAttributes.addFlashAttribute("error", "Invalid CAPTCHA code");
	return "redirect:/contactform";
	}

	// Process file uploads
	try {
	List<String> imageFilenames = processFileUploads(files);
	contactForm.setImageFilenameList(imageFilenames); // Use the proper setter method
	contactFormService.saveContactForm(contactForm);
	redirectAttributes.addFlashAttribute("success", "Contact form submitted successfully!");
	} catch (IOException e) {
	redirectAttributes.addFlashAttribute("error", "File upload failed: " + e.getMessage());
	return "redirect:/contactform";
	}

	return "redirect:/contactform";
	}
		 
		  // Helper methods
		    private List<String> processFileUploads(MultipartFile[] files) throws IOException {
		        List<String> filenames = new ArrayList<>();
		        Path uploadPath = Paths.get(UPLOAD_DIR);
		        
		        if (!Files.exists(uploadPath)) {
		            Files.createDirectories(uploadPath);
		        }

		        for (MultipartFile file : files) {
		            if (!file.isEmpty()) {
		                String originalFilename = file.getOriginalFilename();
		                String fileExtension = originalFilename != null ? 
		                    originalFilename.substring(originalFilename.lastIndexOf(".")) : "";
		                String filename = UUID.randomUUID().toString() + fileExtension;
		                
		                Path filePath = uploadPath.resolve(filename);
		                Files.copy(file.getInputStream(), filePath);
		                filenames.add(filename); // Store only filename, not full path
		            }
		        }
		        return filenames;
		    }

		    private String generateSimpleCaptcha() {
		        return String.valueOf((int)(Math.random() * 90000) + 10000);
		    }
	 
	
}
