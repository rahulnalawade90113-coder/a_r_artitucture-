package in.programing.architecture_website.contactform;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ContactFormRepository extends JpaRepository<ContactForm, Long> {
    List<ContactForm> findAllByOrderByCreatedAtDesc();
}