package in.programing.architecture_website.contactform;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class ContactForm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String contactPersonName;
    private String companyName;
    private String email;
    private String mobileNumber;
    private String phoneNumber;
    private String country;
    private String address;
    private String city;
    private String state;
    private String postalCode;

    @Column(length = 2000)
    private String requirementsDetails;

    private String captcha;
    private String captchaInput; // This won't be stored in DB

    @CreationTimestamp
    private LocalDateTime createdAt;

    // Store image filenames as a comma-separated string
    private String imageFilenames;

    public List<String> getImageFilenameList() {
        if (imageFilenames != null && !imageFilenames.isEmpty()) {
            return List.of(imageFilenames.split(","));
        }
        return new ArrayList<>();
    }

    public void setImageFilenameList(List<String> imageFilenamesList) {
        if (imageFilenamesList != null && !imageFilenamesList.isEmpty()) {
            this.imageFilenames = String.join(",", imageFilenamesList);
        } else {
            this.imageFilenames = null;
        }
    }
}
