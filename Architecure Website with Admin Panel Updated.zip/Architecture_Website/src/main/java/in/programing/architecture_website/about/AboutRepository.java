package in.programing.architecture_website.about;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AboutRepository extends JpaRepository<About, Long> {
    Optional<About> findByName(String name);
    boolean existsByName(String name);
    List<About> findByNameContainingIgnoreCaseOrTitleContainingIgnoreCase(String name, String title);
    List<About> findAllByOrderByIdDesc();
    List<About> findByNameContainingIgnoreCase(String name);

}