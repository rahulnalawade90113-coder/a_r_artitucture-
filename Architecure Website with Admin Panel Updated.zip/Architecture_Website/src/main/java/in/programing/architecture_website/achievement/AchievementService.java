package in.programing.architecture_website.achievement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.UUID;

@Service
public class AchievementService {
    private static final String UPLOAD_DIR = "static/achievements/";

    @Autowired
    private AchievementRepository achievementRepository;

    public Achievement saveAchievement(String title, String shortDescription, 
                                    String fullDescription, MultipartFile file) {
        String imagePath = saveImage(file);
        Achievement achievement = new Achievement(title, shortDescription, fullDescription, imagePath);
        return achievementRepository.save(achievement);
    }

    public Achievement saveAchievement(Achievement achievement) {
        return achievementRepository.save(achievement);
    }

    public Achievement updateAchievement(Long id, String title, String shortDescription, 
                                      String fullDescription, MultipartFile file) {
        Achievement existing = getAchievementById(id);
        if (existing == null) {
            return null;
        }

        if (file != null && !file.isEmpty()) {
            String newImage = saveImage(file);
            if (newImage != null) {
                deleteImage(existing.getImageFilename());
                existing.setImageFilename(newImage);
            }
        }

        existing.setTitle(title);
        existing.setShortDescription(shortDescription);
        existing.setFullDescription(fullDescription);

        return achievementRepository.save(existing);
    }

    public List<Achievement> getAllAchievements() {
        return achievementRepository.findAllByOrderByIdDesc();
    }

    public Achievement getAchievementById(Long id) {
        return achievementRepository.findById(id).orElse(null);
    }

    public void deleteAchievement(Long id) {
        Achievement achievement = getAchievementById(id);
        if (achievement != null) {
            deleteImage(achievement.getImageFilename());
            achievementRepository.deleteById(id);
        }
    }

    String saveImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return null;
        }
        
        try {
            String originalFilename = file.getOriginalFilename();
            String extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            String uniqueFileName = UUID.randomUUID() + extension;
            
            Path uploadPath = Paths.get(UPLOAD_DIR);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            Files.copy(file.getInputStream(), 
                      uploadPath.resolve(uniqueFileName),
                      StandardCopyOption.REPLACE_EXISTING);
            
            return uniqueFileName;
        } catch (IOException e) {
            throw new RuntimeException("Failed to save image: " + e.getMessage(), e);
        }
    }

    void deleteImage(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return;
        }
        
        try {
            Path imagePath = Paths.get(UPLOAD_DIR, fileName);
            Files.deleteIfExists(imagePath);
        } catch (IOException e) {
            throw new RuntimeException("Failed to delete image: " + fileName, e);
        }
    }
}