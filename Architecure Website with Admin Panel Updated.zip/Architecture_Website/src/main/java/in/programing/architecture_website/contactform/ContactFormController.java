package in.programing.architecture_website.contactform;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Controller
public class ContactFormController {

    private final ContactFormService contactFormService;
    private static final String UPLOAD_DIR = "static/contact-forms/";

    public ContactFormController(ContactFormService contactFormService) {
        this.contactFormService = contactFormService;
    }
    
    @GetMapping("/static/contact-forms/{filename:.+}")
    @ResponseBody
    public Resource getImage(@PathVariable String filename) {
        try {
            Path imagePath = Paths.get(UPLOAD_DIR).resolve(filename);
            Resource resource = new UrlResource(imagePath.toUri());

            if (resource.exists() && resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Image not found or not readable");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error loading image: " + filename, e);
        }
    }

    // Show contact form
    @GetMapping("/admin/contact-form")
    public String showContactForm(Model model) {
        model.addAttribute("contactForm", new ContactForm());
        model.addAttribute("captcha", generateSimpleCaptcha());
        model.addAttribute("countries", Arrays.asList("USA", "UK", "India", "Canada", "Australia"));
        return "admin-addcontactform";
    }

    // Process form submission
    @PostMapping("/admin/contact-form")
    public String submitContactForm(@ModelAttribute("contactForm") ContactForm contactForm,
                                  @RequestParam("files") MultipartFile[] files,
                                  RedirectAttributes redirectAttributes) {
        
        // Validate CAPTCHA
        if (!contactForm.getCaptcha().equals(contactForm.getCaptchaInput())) {
            redirectAttributes.addFlashAttribute("error", "Invalid CAPTCHA code");
            return "redirect:/admin-contact-form";
        }

        // Process file uploads
        try {
            List<String> imageFilenames = processFileUploads(files);
            contactForm.setImageFilenameList(imageFilenames); // Use the proper setter method
            contactFormService.saveContactForm(contactForm);
            redirectAttributes.addFlashAttribute("success", "Contact form submitted successfully!");
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "File upload failed: " + e.getMessage());
            return "redirect:/admin/contact-form";
        }

        return "redirect:/admin-contact-list";
    }
    


    // List all contacts with pagination
    @GetMapping("/admin-contact-list")
    public String listContactForms(Model model,
                                 @RequestParam(defaultValue = "1") int page,
                                 @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page - 1, size);
        Page<ContactForm> contactPage = contactFormService.getAllContactForms(pageable);
        
        // For each contact, ensure the image filenames are properly loaded
        contactPage.getContent().forEach(contact -> {
            if (contact.getImageFilenames() != null) {
                contact.setImageFilenameList(contact.getImageFilenameList());
            }
        });
        
        model.addAttribute("contacts", contactPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", contactPage.getTotalPages());
        return "admin-contactformlist";
    }

    // View single contact
    @GetMapping("/contact-list/{id}")
    public String viewContactForm(@PathVariable Long id, Model model) {
        ContactForm contactForm = contactFormService.getContactFormById(id);
        // Ensure image filenames are properly loaded
        contactForm.setImageFilenameList(contactForm.getImageFilenameList());
        model.addAttribute("contact", contactForm);
        return "admin-contact-view";
    }

    // Edit contact form
    @GetMapping("/contact-list/edit/{id}")
    public String editContactForm(@PathVariable Long id, Model model) {
        ContactForm contactForm = contactFormService.getContactFormById(id);
        // Ensure image filenames are properly loaded
        contactForm.setImageFilenameList(contactForm.getImageFilenameList());
        model.addAttribute("contact", contactForm);
        model.addAttribute("countries", Arrays.asList("USA", "UK", "India", "Canada", "Australia"));
        return "admin-contact-edit";
    }

    // Update contact
    @PostMapping("/contact-list/update/{id}")
    public String updateContactForm(@PathVariable Long id,
                                  @ModelAttribute ContactForm contactForm,
                                  @RequestParam(value = "files", required = false) MultipartFile[] files,
                                  RedirectAttributes redirectAttributes) {
        try {
            ContactForm existingContact = contactFormService.getContactFormById(id);
            List<String> existingImages = existingContact.getImageFilenameList();
            
            if (files != null && files.length > 0) {
                List<String> newImageFilenames = processFileUploads(files);
                if (existingImages != null) {
                    existingImages.addAll(newImageFilenames);
                } else {
                    existingImages = newImageFilenames;
                }
            }
            
            contactForm.setId(id);
            contactForm.setImageFilenameList(existingImages);
            contactFormService.saveContactForm(contactForm);
            redirectAttributes.addFlashAttribute("success", "Contact updated successfully");
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Failed to process uploaded files: " + e.getMessage());
        }
        return "redirect:/admin/contact-list";
    }

    // Delete contact
    @GetMapping("/contact-list/delete/{id}")
    public String deleteContactForm(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            ContactForm contactForm = contactFormService.getContactFormById(id);
            // Delete associated files
            List<String> imageFilenames = contactForm.getImageFilenameList();
            if (imageFilenames != null) {
                for (String filename : imageFilenames) {
                    Path filePath = Paths.get(UPLOAD_DIR).resolve(filename);
                    Files.deleteIfExists(filePath);
                }
            }
            
            contactFormService.deleteContactForm(id);
            redirectAttributes.addFlashAttribute("success", "Contact deleted successfully");
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Error deleting contact files: " + e.getMessage());
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error deleting contact: " + e.getMessage());
        }
        return "redirect:/admin/contact-list";
    }

    // Helper methods
    private List<String> processFileUploads(MultipartFile[] files) throws IOException {
        List<String> filenames = new ArrayList<>();
        Path uploadPath = Paths.get(UPLOAD_DIR);
        
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        for (MultipartFile file : files) {
            if (!file.isEmpty()) {
                String originalFilename = file.getOriginalFilename();
                String fileExtension = originalFilename != null ? 
                    originalFilename.substring(originalFilename.lastIndexOf(".")) : "";
                String filename = UUID.randomUUID().toString() + fileExtension;
                
                Path filePath = uploadPath.resolve(filename);
                Files.copy(file.getInputStream(), filePath);
                filenames.add(filename); // Store only filename, not full path
            }
        }
        return filenames;
    }

    private String generateSimpleCaptcha() {
        return String.valueOf((int)(Math.random() * 90000) + 10000);
    }
}
