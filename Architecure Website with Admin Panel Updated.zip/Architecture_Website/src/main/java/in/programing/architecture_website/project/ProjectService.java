package in.programing.architecture_website.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.UUID;

@Service
public class ProjectService {
    private static final String UPLOAD_DIR = "static/projects/";

    @Autowired
    private ProjectRepository projectRepository;

    public Project saveProject(String title, String name, MultipartFile file, String location, String area) {
        String imagePath = saveImage(file);
        Project project = new Project(title, name, imagePath, location, area);
        return projectRepository.save(project);
    }

    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    public Project getProjectById(Long id) {
        return projectRepository.findById(id).orElse(null);
    }

    public void deleteProject(Long id) {
        Project project = getProjectById(id);
        if (project != null) {
            deleteImage(project.getImage());
            projectRepository.deleteById(id);
        }
    }

    private String saveImage(MultipartFile file) {
        if (file.isEmpty()) return null;
        
        try {
            String extension = file.getOriginalFilename()
                .substring(file.getOriginalFilename().lastIndexOf("."));
            String uniqueFileName = UUID.randomUUID() + extension;
            
            Path uploadPath = Paths.get(UPLOAD_DIR);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            Files.copy(file.getInputStream(), 
                      uploadPath.resolve(uniqueFileName),
                      StandardCopyOption.REPLACE_EXISTING);
            
            return uniqueFileName;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void deleteImage(String fileName) {
        if (fileName != null && !fileName.isEmpty()) {
            try {
                Path imagePath = Paths.get(UPLOAD_DIR, fileName);
                Files.deleteIfExists(imagePath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}