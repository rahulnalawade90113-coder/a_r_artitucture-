package in.programing.architecture_website.contact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ContactService {
    @Autowired
    private ContactRepository contactRepository;

    public Contact saveContact(String mobileNumber, String address, String email) {
        Contact contact = new Contact(mobileNumber, address, email);
        return contactRepository.save(contact);
    }

    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }

    public Contact getContactById(Long id) {
        return contactRepository.findById(id).orElse(null);
    }

    public void deleteContact(Long id) {
        contactRepository.deleteById(id);
    }

    public Contact updateContact(Long id, String mobileNumber, String address, String email) {
        Contact contact = getContactById(id);
        if (contact != null) {
            if (mobileNumber != null) contact.setMobileNumber(mobileNumber);
            if (address != null) contact.setAddress(address);
            if (email != null) contact.setEmail(email);
            return contactRepository.save(contact);
        }
        return null;
    }
}