package in.programing.architecture_website.about;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/about")
public class AboutController {
    @Autowired
    private AboutService aboutService;

    @GetMapping
    public String listAbout(Model model) {
        model.addAttribute("aboutList", aboutService.getAllAbout());
        return "admin-listabout";
    }
    
    @GetMapping("/view")
    public String showAbout(Model model) {
        model.addAttribute("aboutList", aboutService.getAllAbout());
        return "aboutsss";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("about", new About());
        return "admin-addabout";
    }

    @PostMapping("/save")
    public String saveAbout(@RequestParam String name,
                          @RequestParam String title,
                          @RequestParam String shortName,
                          @RequestParam String description,
                          @RequestParam String logoEmoji) {
        aboutService.saveAbout(name, title, shortName, description, logoEmoji);
        return "redirect:/admin/about";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        About about = aboutService.getAboutById(id);
        model.addAttribute("about", about);
        return "admin/about/edit";
    }

    @PostMapping("/update/{id}")
    public String updateAbout(@PathVariable Long id,
                            @RequestParam String name,
                            @RequestParam String title,
                            @RequestParam String shortName,
                            @RequestParam String description,
                            @RequestParam String logoEmoji) {
        aboutService.updateAbout(id, name, title, shortName, description, logoEmoji);
        return "redirect:/admin/about";
    }

    @GetMapping("/delete/{id}")
    public String deleteAbout(@PathVariable Long id) {
        aboutService.deleteAbout(id);
        return "redirect:/admin/about";
    }
}
