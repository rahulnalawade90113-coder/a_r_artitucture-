package in.programing.architecture_website.companydetails;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class CompanyDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String title;
    private String shortDescription;
    private String longDescription;
    private String imageFilename;
    private String imageFilename1;
    private String imageFilename2;
    private Integer year;
    private Integer projectsCompleted;
    private Integer clientsServed;
    
    public CompanyDetails() {}
    
    public CompanyDetails(String title, String shortDescription, String longDescription, 
                        String imageFilename,  String imageFilename1, String imageFilename2, Integer year, Integer projectsCompleted, 
                        Integer clientsServed) {
        this.title = title;
        this.shortDescription = shortDescription;
        this.longDescription = longDescription;
        this.imageFilename = imageFilename;
        this.imageFilename1 = imageFilename1;
        this.imageFilename2 = imageFilename2;
        this.year = year;
        this.projectsCompleted = projectsCompleted;
        this.clientsServed = clientsServed;
    }
}
