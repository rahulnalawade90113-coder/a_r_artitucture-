package in.programing.architecture_website.about;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class About {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String title;
    private String shortName;
    private String description;
    private String logoEmoji;
    
    public About() {}
    
    public About(String name, String title, String shortName, 
                String description, String logoEmoji) {
        this.name = name;
        this.title = title;
        this.shortName = shortName;
        this.description = description;
        this.logoEmoji = logoEmoji;
    }
}
