package in.programing.architecture_website.project;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String name;
    private String image;
    private String location;  // Added field
    private String area;      // Added field

    public Project() {}

    public Project(String title, String name, String image, String location, String area) {
        this.title = title;
        this.name = name;
        this.image = image;
        this.location = location;
        this.area = area;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }
    public String getLocation() { return location; }  // Added getter
    public void setLocation(String location) { this.location = location; }  // Added setter
    public String getArea() { return area; }  // Added getter
    public void setArea(String area) { this.area = area; }  // Added setter
}