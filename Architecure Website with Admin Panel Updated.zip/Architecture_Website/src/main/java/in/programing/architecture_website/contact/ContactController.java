package in.programing.architecture_website.contact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ContactController {
    @Autowired
    private ContactService contactService;

    @GetMapping("/addcontact")
    public String showAddContactForm(Model model) {
        model.addAttribute("contact", new Contact());
        return "admin-addcontact";
    }

    @PostMapping("/addcontact")
    public String saveContact(
            @RequestParam("mobileNumber") String mobileNumber,
            @RequestParam("address") String address,
            @RequestParam("email") String email,
            RedirectAttributes redirectAttributes) {
        
        contactService.saveContact(mobileNumber, address, email);
        redirectAttributes.addFlashAttribute("success", "Contact added successfully!");
        return "redirect:/contactlist";
    }

    @GetMapping("/contactlist")
    public String showContactList(Model model) {
        model.addAttribute("contacts", contactService.getAllContacts());
        return "admin-contactlist";
    }

    @GetMapping("/contact")
    public String showContactsPage(Model model) {
        model.addAttribute("contacts", contactService.getAllContacts());
        return "contact";
    }
    

    @GetMapping("/contact-edit-{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Contact contact = contactService.getContactById(id);
        model.addAttribute("contact", contact);
        return "admin-editcontact";
    }

    @PostMapping("/contact/update/{id}")
    public String updateContact(
            @PathVariable Long id,
            @RequestParam("mobileNumber") String mobileNumber,
            @RequestParam("address") String address,
            @RequestParam("email") String email,
            RedirectAttributes redirectAttributes) {
        
        contactService.updateContact(id, mobileNumber, address, email);
        redirectAttributes.addFlashAttribute("success", "Contact updated successfully!");
        return "redirect:/contactlist";
    }

    @GetMapping("/contact/delete/{id}")
    public String deleteContact(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        contactService.deleteContact(id);
        redirectAttributes.addFlashAttribute("success", "Contact deleted successfully!");
        return "redirect:/contactlist";
    }
}