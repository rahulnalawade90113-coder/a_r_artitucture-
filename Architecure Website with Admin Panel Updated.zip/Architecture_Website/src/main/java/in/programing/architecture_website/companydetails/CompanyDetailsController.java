package in.programing.architecture_website.companydetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class CompanyDetailsController {
    @Autowired
    private CompanyDetailsService companyDetailsService;

    @GetMapping("/admin-company-details")
    public String listCompanyDetails(Model model) {
        model.addAttribute("companyDetailsList", companyDetailsService.getAllCompanyDetails());
        return "listcompanydetails";
    }
    
  

    @GetMapping("/admin-company-details-add")
    public String showAddForm(Model model) {
        model.addAttribute("companyDetails", new CompanyDetails());
        return "addcompanydetails";
    }

    @PostMapping("/admin-company-details-save")
    public String saveCompanyDetails(@RequestParam String title,
                                   @RequestParam String shortDescription,
                                   @RequestParam String longDescription,
                                   @RequestParam MultipartFile file,
                                   @RequestParam MultipartFile file1,
                                   @RequestParam MultipartFile file2,
                                   @RequestParam Integer year,
                                   @RequestParam Integer projectsCompleted,
                                   @RequestParam Integer clientsServed) {
        companyDetailsService.saveCompanyDetails(title, shortDescription, longDescription, 
                                              file, file1, file2,
                                              year, projectsCompleted, clientsServed);
        return "redirect:/admin-company-details";
    }

    @GetMapping("admin-company-details-edit-{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        CompanyDetails details = companyDetailsService.getCompanyDetailsById(id);
        model.addAttribute("companyDetails", details);
        return "editcompanydetails";
    }

    @PostMapping("/admin-company-details-update-{id}")
    public String updateCompanyDetails(@PathVariable Long id,
                                     @RequestParam String title,
                                     @RequestParam String shortDescription,
                                     @RequestParam String longDescription,
                                     @RequestParam(required = false) MultipartFile file,
                                     @RequestParam(required = false) MultipartFile file1,
                                     @RequestParam(required = false) MultipartFile file2,
                                     @RequestParam Integer year,
                                     @RequestParam Integer projectsCompleted,
                                     @RequestParam Integer clientsServed) {
        companyDetailsService.updateCompanyDetails(id, title, shortDescription, longDescription, 
                                                 file, file1, file2,
                                                 year, projectsCompleted, clientsServed);
        return "redirect:/admin-company-details";
    }

    @GetMapping("/admin-company-details-delete-{id}")
    public String deleteCompanyDetails(@PathVariable Long id) {
        companyDetailsService.deleteCompanyDetails(id);
        return "redirect:/admin-company-details";
    }
}
