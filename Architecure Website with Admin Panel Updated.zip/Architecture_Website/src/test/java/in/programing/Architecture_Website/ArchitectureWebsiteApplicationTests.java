package in.programing.Architecture_Website;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchitectureWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
